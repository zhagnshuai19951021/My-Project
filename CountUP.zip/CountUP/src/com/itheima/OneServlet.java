package com.itheima;

import javax.jms.Session;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.*;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Map;
import java.util.Set;

/**
 * @Author Zhang Shuai
 * @Date 2020/9/2 22:24
 * @Version 1.0
 */
@WebServlet(name = "OneServlet",urlPatterns ="/demo")
public class OneServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


        String kaoyantime = request.getParameter("kaoyantime");
        System.out.println(kaoyantime);
        Date twotime=new Date();
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        try {
            twotime = df.parse(kaoyantime);
            System.out.println("这是将要考研的日期"+twotime);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        Date onetime = new Date();
        long starttime = onetime.getTime();
        long endtime = twotime.getTime();
        long milliSecond = endtime - starttime;

        long endsdays = milliSecond / (24 * 3600 * 1000);
        System.out.println("这是当前的日期"+onetime);
        System.out.println("考研剩余的天数"+endsdays);
        ArrayList<Long> DEMO = new ArrayList<Long>();
        DEMO.add(endsdays);
        HttpSession session = request.getSession();
        session.setAttribute("endsdays", endsdays);
        /*请求转发到这个页面中去*/
        request.getRequestDispatcher("index.jsp").forward(request,response);





    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
